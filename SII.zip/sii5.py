dx = [0, 0, 1, -1]
dy = [1, -1, 0, 0]


def getMatrix(side):
    M = [[{"e": None, "d": 0, "v": False} for y in range(m)] for x in range(n)]
    if side == 'up':
        for i in range(n):
            for j in range(m):
                if i >= (n - n_miss) and j < m_miss:
                    M[i][j]['e'] = 0
                else:
                    M[i][j]['e'] = 1
    else:
        for i in range(n):
            for j in range(m):
                if i < n_miss and j >= (m - m_miss):
                    M[i][j]['e'] = 0
                else:
                    M[i][j]['e'] = 1

    for i in range(n):
        for j in range(m):
            M[i][j]['d'] = i + j

    return M


def verif(x, y):
    if x < 0 or x >= n or y < 0 or y >= m:
        return False
    return True


def choose(l):
    ret = None
    for r in l:
        x, y = r
        if x == 0 or y == 0 or x == n - 1 or y == m - 1:
            return r
        for i in range(4):
            xx = x + dx[i]
            yy = y + dy[i]
            if not verif(xx, yy):
                continue
            if M[xx][yy]['e'] == 0:
                continue
            if M[xx][yy]['v']:
                ret = r
                break
    return ret


def advance(r, path):
    global re
    global vCells
    while True:
        x, y = r
        if not M[x][y]['v']:
            vCells = vCells + 1
            path.append((x, y))
        M[x][y]['v'] = True
        re = re - 1
        maxim = M[x][y]['d']
        l = []
        for i in range(4):
            xx = x + dx[i]
            yy = y + dy[i]
            if not verif(xx, yy):
                continue
            if M[xx][yy]['e'] == 0 or M[xx][yy]['v']:
                continue
            if M[xx][yy]['d'] > maxim:
                maxim = M[xx][yy]['d']
                l.append((xx, yy))

        if maxim == M[x][y]['d']:
            r = (x, y)
            break
        r = choose(l)

    return r


def check(x, y):
    up = False
    down = False
    if verif(x - 1, y + 1) and not M[x - 1][y + 1]['v'] and M[x - 1][y + 1]['e'] == 1:
        up = True

    if verif(x + 1, y - 1) and not M[x + 1][y - 1]['v'] and M[x + 1][y - 1]['e'] == 1:
        down = True

    return up and down


def follow(r, path):
    x, y = r
    global re
    global vCells

    while re > M[x][y]['d']:
        x, y = r

        if not M[x][y]['v']:
            vCells = vCells + 1
            path.append((x, y))
        M[x][y]['v'] = True

        if verif(x - 1, y + 1) and not M[x - 1][y + 1]['v'] and M[x - 1][y + 1]['e'] == 1:
            r = (x - 1, y + 1)
            re = re - 2
        elif verif(x + 1, y - 1) and not M[x + 1][y - 1]['v'] and M[x + 1][y - 1]['e'] == 1:
            r = (x + 1, y - 1)
            re = re - 2
        elif check(x - 1, y):
            r = (x, y - 1)
            re = re - 1
        elif verif(x, y - 1) or not M[x - 1][y]['v'] or M[x][y - 1]['e'] == 0:
            r = (x - 1, y)
            re = re - 1
        elif verif(x, y - 1) and M[x - 1][y]['v']:
            r = (x, y - 1)
            re = re - 1
        else:
            break

    return r


def algthCC():
    global re
    global vCells
    output = []
    start = (0, 1)
    a = 0
    i = 1
    while vCells < nrOfCells:
        path = []
        r = advance(start, path)
        p = follow(r, path)

        if i % 2 == 1:
            start = p
            a = a + 1
        else:
            start = (a, 1)
        re = m + n - 2 + alpha + 1
        output.append(path)
        i = i + 1

    return output

m = 9
n = 8
n_miss = 2
m_miss = 4
alpha = 5

re = m + n - 2 + alpha
M = getMatrix('down')

for line in reversed(M):
    print(line)

vCells = 1
nrOfCells = m * n - m_miss * n_miss

print(algthCC())

for line in M:
    print(line)
