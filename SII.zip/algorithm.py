import numpy as np

status = np.zeros((7, 6), dtype=int)


def read_file(file_name):
        with open(file_name, 'r', encoding='utf-8-sig') as f:
                l = [[int(num) for num in line.split()] for line in f]
        return l

def advance(env, status, m, n, iS, jS, iF, jF, Re):
        i = iS
        j = jS
        while ((i != iF) or (j != jF)):
                if ((j + 1 < n) and (status[i][j+1] == 0)):
                        j += 1
                        status[i][j] = 1
                        Re -= 1
                elif ((i - 1 >= 0) and (status[i-1][j] == 0)):
                        i -= 1
                        status[i][j] = 1
                        Re -= 1
        return

def follow(env, status, Re, iC, jC, m, n):
        i = iC
        j = jC
        while (Re > env[i][j]):
                status[i][j] = 1
                if ((i-1 >= 0) and (j-1 >= 0) and (status[i-1][j-1] == 0)):
                        status[i-1][j-1] = 1
                        i -= 1
                        j -= 1
                        Re -= 2
                elif ((i+1 < m) and (j+1 < n) and (status[i+1][j+1] == 0)):
                        status[i+1][j+1] = 1
                        i += 1
                        j += 1
                        Re -= 2
                elif 

env = read_file('dim10x10.txt')
advance(env, status, 7, 6, 6, 0, 0, 5, 22)

#print (status)
#print (env)

