def two():
    M = [[{"e": 1, "d": 0, "v": False} for y in range(m)] for x in range(n)]
    for i in range(n - miss_2[0], n):
        for j in range(m - miss_2[1], m):
            M[i][j]['e'] = 0

    for i in range(n):
        for j in range(m):
            M[i][j]['d'] = i + j

    return M

def three_left():
    M = [[{"e": 1, "d": 0, "v": False} for y in range(m)] for x in range(n)]

    for i in range(miss_3[1], n - miss_3[0]):
        for j in range(miss_3[2]):
            M[i][j]['e'] = 0

    for i in range(n):
        for j in range(m):
            M[i][j]['d'] = i + j

    return M

def three_up():
    M = [[{"e": 1, "d": 0, "v": False} for y in range(m)] for x in range(n)]

    for i in range(n - miss_3[0], n):
        for j in range(miss_3[1], m - miss_3[2]):
            M[i][j]['e'] = 0

    for i in range(n):
        for j in range(m):
            M[i][j]['d'] = i + j

    return M

def three_right():
    M = [[{"e": 1, "d": 0, "v": False} for y in range(m)] for x in range(n)]

    for i in range(miss_3[1], n - miss_3[0]):
        for j in range(m - miss_3[2], m):
            M[i][j]['e'] = 0

    for i in range(n):
        for j in range(m):
            M[i][j]['d'] = i + j

    return M

def three_down():
    M = [[{"e": 1, "d": 0, "v": False} for y in range(m)] for x in range(n)]

    for i in range(miss_3[0]):
        for j in range(miss_3[1], m - miss_3[2]):
            M[i][j]['e'] = 0

    for i in range(n):
        for j in range(m):
            M[i][j]['d'] = i + j

    return M

def four():
    M = [[{"e": 1, "d": 0, "v": False} for y in range(m)] for x in range(n)]

    for i in range(miss_4[0], n - miss_4[1]):
        for j in range(miss_4[2], m - miss_4[3]):
            M[i][j]['e'] = 0

    for i in range(n):
        for j in range(m):
            M[i][j]['d'] = i + j

    return M

def get_env(argument):
    switcher = {
        1: two,
        2: three_left,
        3: three_up,
        4: three_right,
        5: three_down,
        6: four
    }

    matrix = switcher.get(argument, "Invalid request.")
    return matrix()

m = 12
n = 7
miss_2 = None
miss_3 = None
miss_4 = None
miss_2 = (1, 7)
miss_3 = (2, 1, 2) #miss_3[0] = numarul de randuri ce exista in sus si miss_3[1] = numarul de linii ce exista in jos
miss_4 = (1, 2, 1, 2)

M = get_env(1)
for line in reversed(M):
    print(line)