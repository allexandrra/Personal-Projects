dx = [0, 0, 1, -1]
dy = [1, -1, 0, 0]


def getMatrix(side):
    M = [[{"exists": None, "distance": 0, "visited": False} for y in range(m)] for x in range(n)]
    if side == 'up':
        for i in range(n):
            for j in range(m):
                if i >= (n - n_miss) and j < m_miss:
                    M[i][j]['exists'] = 0
                else:
                    M[i][j]['exists'] = 1
    else:
        for i in range(n):
            for j in range(m):
                if i < m_miss and j >= (m - m_miss):
                    M[i][j]['exists'] = 0
                else:
                    M[i][j]['exists'] = 1

    for i in range(n):
        for j in range(m):
            M[i][j]['distance'] = i + j

    return M


def verif(x, y):
    if x < 0 or x >= n or y < 0 or y >= m:
        return False
    return True


def choose(l):
    ret = None
    for r in l:
        x, y = r
        if x == 0 or y == 0 or x == n - 1 or y == m - 1:
            return r
        for i in range(4):
            xx = x + dx[i]
            yy = y + dy[i]
            if not verif(xx, yy):
                continue
            if M[xx][yy]['exists'] == 0:
                continue
            if M[xx][yy]['visited']:
                ret = r
                break
    return ret


def advance(r):
    global re
    while True:
        x, y = r
        M[x][y]['visited'] = True
        re = re - 1
        maxim = M[x][y]['distance']
        l = []
        for i in range(4):
            xx = x + dx[i]
            yy = y + dy[i]
            if not verif(xx, yy):
                continue
            if M[xx][yy]['exists'] == 0 or M[xx][yy]['visited']:
                continue
            if M[xx][yy]['distance'] > maxim:
                maxim = M[xx][yy]['distance']
                l.append((xx, yy))

        if maxim == M[x][y]['distance']:
            r = (x, y)
            break
        r = choose(l)

    return r


def check(x, y):
    up = False
    down = False
    if verif(x - 1, y + 1) and not M[x - 1][y + 1]['visited'] and M[x - 1][y + 1]['exists'] == 1:
        up = True

    if verif(x + 1, y - 1) and not M[x + 1][y - 1]['visited'] and M[x + 1][y - 1]['exists'] == 1:
        down = True

    return up and down


def follow(r):
    x, y = r
    global re
    while re > M[x][y]['distance']:
        x, y = r

        M[x][y]['visited'] = True

        if verif(x - 1, y + 1) and not M[x - 1][y + 1]['visited'] and M[x - 1][y + 1]['exists'] == 1:
            r = (x - 1, y + 1)
            re = re - 2
        elif verif(x + 1, y - 1) and not M[x + 1][y - 1]['visited'] and M[x + 1][y - 1]['exists'] == 1:
            r = (x + 1, y - 1)
            re = re - 2
        elif check(x - 1, y):
            r = (x, y - 1)
            re = re - 1
        elif verif(x, y - 1) or not M[x - 1][y]['visited'] or M[x][y - 1]['exists'] == 0:
            r = (x - 1, y)
            re = re - 1
        elif verif(x, y - 1) and M[x - 1][y]['visited']:
            r = (x, y - 1)
            re = re - 1
        else:
            break
    return


# m = 8
# n = 8
# n_miss = 2
# m_miss = 2

# M = getMatrix('down')
# print(advance((0,0)))
# for line in reversed(M):
#    print(line)

m = 6
n = 6
n_miss = 2
m_miss = 2
alpha = 3

re = m + n - 2 + alpha

M = getMatrix('down')

r = advance((0, 0))
print(r)
print('\n')

for line in M:
    print(line)

print('\n')
follow(r)

for line in M:
    print(line)
