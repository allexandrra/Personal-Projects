dx = [0, 0, 1, -1]
dy = [1, -1, 0, 0]


def getMatrix(side):
    M = [[{"exists": None, "distance": 0, "visited": False} for y in range(m)] for x in range(n)]
    if side == 'up':
        for i in range(n):
            for j in range(m):
                if i >= (n - n_miss) and j < m_miss:
                    M[i][j]['exists'] = 0
                else:
                    M[i][j]['exists'] = 1
    else:
        for i in range(n):
            for j in range(m):
                if i < m_miss and j >= (m - m_miss):
                    M[i][j]['exists'] = 0
                else:
                    M[i][j]['exists'] = 1

    for i in range(n):
        for j in range(m):
            M[i][j]['distance'] = i + j

    return M


def verif(x, y):
    if x < 0 or x >= n or y < 0 or y >= m:
        return False
    return True


def choose(l):
    ret = None
    for r in l:
        x, y = r
        if x == 0 or y == 0 or x == n - 1 or y == m - 1:
            return r
        for i in range(4):
            xx = x + dx[i]
            yy = y + dy[i]
            if not verif(xx, yy):
                continue
            if M[xx][yy]['exists'] == 0:
                continue
            if M[xx][yy]['visited']:
                ret = r
                break
    return ret


def visit(x, y):
    global visitedCells
    global re
    re = re - 1
    if not M[x][y]['visited']:
        visitedCells = visitedCells + 1
        M[x][y]['visited'] = True


def reachDest(x, y, path, dest):
    while True:  # se urca pana la destinatie (n - 1, m - 1)
        if x < dest[0]:
            x = x + 1
        elif y > dest[1]:
            y = y - 1

        visit(x, y)
        path.append((x, y))
        if x == dest[0] and y == dest[1]:
            t = (x, y)
            return t


def advance(r, path, dest):
    global re
    global visitedCells
    while True:
        x, y = r
        if not M[x][y]['visited']:
            visitedCells = visitedCells + 1
            M[x][y]['visited'] = True

        path.append((x, y))
        ok = False

        while not M[x][y + 1]['exists']:  # cat timp la dreapta este golul
            x = x + 1
            if not verif(x, y):
                return
            visit(x, y)
            path.append((x, y))

        if verif(x, y + 1) and M[x][y + 1]['exists']:
            if M[x][y + 1]['visited']:  # daca in dreapta e vizitat
                while verif(x + 1, y) and M[x + 1][y]['exists']:  # se merge in sus
                    x = x + 1
                    visit(x, y)
                    path.append((x, y))
                    if not M[x][y]['visited']:  # daca aceasta casuta nu este vizitata
                        ok = True  # se poate merge la dreapta
                        break
                if not ok:  # daca s-a ajuns la capatul directiei sus, insa la dreapta tot e vizitat
                    while not M[x + 1][y]['exists']:  # cat timp nu se poate merge in sus
                        y = y + 1  # mergem catre dreapta
                        visit(x, y)
                        path.append((x, y))
                    while M[x][y]['visited']:  # se merge iar in sus pana la prima casuta nevizitata
                        x = x + 1
                        visit(x, y)
                        path.append((x, y))
                    ok = True

            else:
                ok = True  # este deja vizitata si se poate merge

        while not M[x][y + 1]['visited']:
            y = y + 1
            visit(x, y)
            path.append((x, y))
            if not verif(x, y + 1):  # daca e la marginea matricei
                return reachDest(x, y, path, dest)
            if not M[x][y + 1]['exists']:  # daca la dreapta nu "exista" ( este patratul gol)
                while not M[x][y + 1]['exists']:  # se urca pana se depaseste patratul gol
                    x = x + 1
                    visit(x, y)
                    path.append((x, y))
                continue
        # se misca pe langa partea dreapta vizitata
        while M[x][y + 1]['visited'] and not M[x + 1][y]['visited']:  # cat timp la dreapta e vizitat si sus e liber
            x = x + 1  # urca pana da de prima casuta vizitata
            visit(x, y)
            path.append((x, y))

        if M[x + 1][y]['visited']:  # daca
            return reachDest(x, y, path, dest)  # incepe cautarea

        while not M[x][y + 1]['visited']:  # caz depasire gol dupa prima cale
            y = y + 1
            visit(x, y)
            path.append((x, y))

        while not M[x + 1][y]['visited']:  # urca cat timp sus nu e vizitat
            x = x + 1
            visit(x, y)
            path.append((x, y))

        # cauta
        return reachDest(x, y, dest)


def check(x, y):
    up = False
    down = False
    if verif(x - 1, y + 1) and not M[x - 1][y + 1]['visited'] and M[x - 1][y + 1]['exists'] == 1:
        up = True

    if verif(x + 1, y - 1) and not M[x + 1][y - 1]['visited'] and M[x + 1][y - 1]['exists'] == 1:
        down = True

    return up and down


def follow(r, path):
    x, y = r
    global re
    global visitedCells
    while re > M[x][y]['distance']:
        x, y = r

        if verif(x - 1, y + 1) and not M[x - 1][y + 1]['visited'] and M[x - 1][y + 1]['exists'] == 1:
            r = (x - 1, y + 1)
            re = re - 2
        elif verif(x + 1, y - 1) and not M[x + 1][y - 1]['visited'] and M[x + 1][y - 1]['exists'] == 1:
            r = (x + 1, y - 1)
            re = re - 2
        elif x == n - 1:  # daca este sus
            if verif(x, y - 1) and not M[x][y - 1]['visited'] and M[x][y - 1]['exists'] == 1:  # se uita mai intai la stanga
                r = (x, y - 1)
                re = re - 1
            elif verif(x - 1, y) and not M[x - 1][y]['visited'] and M[x - 1][y]['exists'] == 1:  # dupa care jos
                r = (x - 1, y)
                re = re - 1
        elif verif(x - 1, y) and not M[x - 1][y]['visited'] and M[x - 1][y]['exists'] == 1:  # se uita jos
            r = (x - 1, y)
            re = re - 1
        elif verif(x, y - 1) and not M[x][y - 1]['visited'] and M[x][y - 1]['exists'] == 1:  # se uita la stanga
            r = (x, y - 1)
            re = re - 1
        else:
            x, y = r
            visit(x, y)
            path.append((x, y))
            return r
        x, y = r
        visit(x, y)
        re = re + 1
        path.append((x, y))

    return r


def algthCC():
    global re
    global visitedCells
    output = []
    start = (0, 0)
    i = 1
    dest = None
    while visitedCells < nrOfCells:
        path = []
        if i == 1:
            dest = (n - 1, m - 1)
        if i % 2 == 1:
            r = advance(start, path, dest)
            dest = follow(r, path)
        if i % 2 == 0:
            re = re + 1 - (dest[0] + dest[1])
            dest = follow(dest, path)
        re = 2 * (m + n - 2) + alpha
        output.append(path)
        i = i + 1

    return output


# m = 8
# n = 8
# n_miss = 2
# m_miss = 2

# M = getMatrix('down')
# print(advance((0,0)))
# for line in reversed(M):
#    print(line)

m = 9
n = 8
n_miss = 5
m_miss = 4
alpha = 5

re = 2 * (m + n - 2) + alpha

M = getMatrix('up')
visitedCells = 1
nrOfCells = m * n - m_miss * n_miss

# tralala = []
# r = advance((0, 0), tralala)
# print(r, tralala)

print(algthCC())
for line in reversed(M):
    print(line)
