package procese;

public class RoundRobinScheduler{
	
	public static void RRS(int nrOfEvents, ProcessStructure[] processes, int nrOfNumbers, int[] numbersToBeProcessed) {
		
		
		}
		
	}
