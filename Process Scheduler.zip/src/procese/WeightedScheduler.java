package procese;

public class WeightedScheduler {
	
	public static void WS() {
		
		
		
	}

}
