package procese;

public class Square {
	
	public static int SquareNumber(int number) {
		return number * number;
	}
}
