package procese;

public class Cube {

	public static int CubeNumber(int number) {
		return number * number * number;
	}
}
